import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider, CssBaseline } from "@mui/material";
import { UserProvider } from "./context/UserContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Home from "./components/Home";
import Bookings from "./components/Bookings";
import Login from "./components/Login";
import Signup from "./components/Signup";
import theme from "./theme";

function App() {
	return (
		<ThemeProvider theme={theme}>
			<UserProvider>
				<BrowserRouter>
					<AppContent />
				</BrowserRouter>
			</UserProvider>
		</ThemeProvider>
	);
}

function AppContent() {
	return (
		<>
			<CssBaseline />
			<Routes>
				<Route
					path="/"
					element={
						<ProtectedRoute>
							<Home />
						</ProtectedRoute>
					}
				/>
				<Route
					path="/bookings"
					element={
						<ProtectedRoute>
							<Bookings />
						</ProtectedRoute>
					}
				/>
				<Route path="/login" element={<Login />} />
				<Route path="/signup" element={<Signup />} />
			</Routes>
		</>
	);
}

export default App;
