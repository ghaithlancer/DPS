import axios from "axios";
import { jwtDecode } from "jwt-decode";
import { useNavigate } from "react-router-dom"; // Import useNavigate for redirection

const API_BASE_URL =
	"https://us-central1-dpservices-f7887.cloudfunctions.net/api";
// "http://localhost:5000/dpservices-f7887/us-central1/api";

// Create an instance of axios with the API base URL
const apiClient = axios.create({
	baseURL: API_BASE_URL,
	headers: {
		"Content-Type": "application/json",
	},
});

// Axios interceptor to attach the token to every request
apiClient.interceptors.request.use(
	(config) => {
		const token = localStorage.getItem("token");
		if (token) {
			config.headers["Authorization"] = `Bearer ${token}`;
		}
		return config;
	},
	(error) => Promise.reject(error)
);

// Function to check if the token is valid
const isTokenValid = () => {
	const token = localStorage.getItem("token");
	if (!token) return false;

	const decodedToken = jwtDecode(token);
	return decodedToken.exp * 1000 > Date.now();
};

// Authentication and user management
export const signup = (userData) =>
	apiClient.post("/staff/signup", userData).then((response) => {
		const { token, signedInUser } = response.data;
		localStorage.setItem("token", token);
		return { user: signedInUser, token };
	});

export const login = (credentials) =>
	apiClient.post("/staff/login", credentials).then((response) => {
		const { token, signedInUser } = response.data;
		localStorage.setItem("token", token);
		return { user: signedInUser, token };
	});

// Bookings management
export const createBooking = (bookingData, serviceType) =>
	apiClient.post(`/staff/${serviceType}`, bookingData);

export const fetchBookings = () => apiClient.get("/staff/bookings");

export const deleteBooking = (bookingId) =>
	apiClient.delete(`/staff/booking/${bookingId}`);

export const cancelBooking = (bookingId) =>
	apiClient.post(`/staff/cancelBooking/${bookingId}`);

// Handle automatic login
export const handleAutoLogin = () => {
	if (isTokenValid()) {
		console.log("User is still logged in.");
	} else {
		console.log("Session expired.");
		localStorage.removeItem("token"); // Clear the token if it is not valid
	}
};

// Initialize user session
export const initializeUserSession = () => {
	const navigate = useNavigate(); // Hook for navigation
	const token = localStorage.getItem("token");
	if (token && isTokenValid(token)) {
		navigate("/");
	} else {
		console.log("Session expired or no token found.");
		localStorage.removeItem("token"); // Clear the token if it is not valid
	}
};

// Handle logout
export const logout = () => {
	localStorage.removeItem("token"); // Remove the token from local storage
	console.log("Logged out successfully.");
};

export default {
	signup,
	login,
	createBooking,
	fetchBookings,
	deleteBooking,
	handleAutoLogin,
	initializeUserSession,
	logout,
};
