import React, { useState, useEffect } from "react";
import {
	Grid,
	Button,
	Card,
	CardContent,
	Typography,
	Container,
	ThemeProvider,
	IconButton,
	Dialog,
	DialogActions,
	DialogContent,
	DialogContentText,
	DialogTitle,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import { fetchBookings, deleteBooking, cancelBooking } from "../api/apiService";
import theme from "../theme";
import Menu from "./Menu";
import moment from "moment-timezone";
import "./style.css";

function Bookings() {
	const [bookings, setBookings] = useState([]);
	const [activeTab, setActiveTab] = useState("Pending");
	const [openDialog, setOpenDialog] = useState(false);
	const [currentBookingId, setCurrentBookingId] = useState(null);
	const [isCancelAction, setIsCancelAction] = useState(false);

	useEffect(() => {
		fetchBookings()
			.then((response) => {
				const bookingsWithConvertedDates = response.data.map((booking) => ({
					...booking,
					start: new Date(booking.start._seconds * 1000),
					end: new Date(booking.end._seconds * 1000),
				}));
				setBookings(bookingsWithConvertedDates);
			})
			.catch((error) => {
				console.error("Failed to fetch bookings:", error);
			});
	}, []);

	const handleOpenDialog = (bookingId, isCancel) => {
		setCurrentBookingId(bookingId);
		setIsCancelAction(isCancel);
		setOpenDialog(true);
	};

	const handleCloseDialog = () => {
		setOpenDialog(false);
	};

	const handleDelete = () => {
		deleteBooking(currentBookingId)
			.then(() => {
				setBookings((currentBookings) =>
					currentBookings.filter((b) => b.bookingId !== currentBookingId)
				);
				handleCloseDialog();
			})
			.catch((error) => {
				console.error("Failed to delete booking:", error);
				handleCloseDialog();
			});
	};

	const handleCancel = () => {
		cancelBooking(currentBookingId)
			.then(() => {
				setBookings((currentBookings) =>
					currentBookings.map((booking) =>
						booking.bookingId === currentBookingId
							? { ...booking, status: "Cancelled" }
							: booking
					)
				);
				handleCloseDialog();
			})
			.catch((error) => {
				console.error("Failed to cancel booking:", error);
				handleCloseDialog();
			});
	};

	const filteredBookings = bookings.filter((booking) => {
		const bookingDate = new Date(booking.start);
		const now = new Date();
		return (
			(activeTab === "Completed" && booking.status === "Completed") ||
			(activeTab === "Reserved" &&
				["Accepted", "Cancelled"].includes(booking.status)) ||
			(activeTab === "Pending" &&
				booking.status === "Pending" &&
				bookingDate >= now)
		);
	});

	const formatDate = (date) => moment(date).format("MMM D YYYY h:mm A");

	return (
		<ThemeProvider theme={theme}>
			<Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
				<Menu />
				<Grid container spacing={2}>
					<Grid item xs={12}>
						<Grid container justifyContent="center" spacing={2}>
							{["Pending", "Reserved", "Completed"].map((status) => (
								<Grid key={status} item>
									<Button
										variant={activeTab === status ? "contained" : "outlined"}
										onClick={() => setActiveTab(status)}
										sx={{
											backgroundColor:
												activeTab === status ? theme.palette.primary.main : "",
											color: activeTab === status ? "#1a1a1a" : "#ffffff",
										}}
									>
										<strong>{status}</strong>
									</Button>
								</Grid>
							))}
						</Grid>
					</Grid>
					<Grid item xs={12}>
						{filteredBookings.map((booking, index) => (
							<Card
								key={index}
								sx={{
									backgroundColor: theme.palette.primary.main,
									mb: 2,
									position: "relative",
								}}
							>
								{activeTab !== "Completed" &&
									(booking.status === "Pending" ||
										booking.status === "Accepted") && (
										<IconButton
											onClick={() =>
												handleOpenDialog(
													booking.bookingId,
													booking.status === "Accepted"
												)
											}
											sx={{
												position: "absolute",
												top: 10,
												right: 10,
												color: "#FF474C",
											}}
											aria-label={
												booking.status === "Accepted"
													? "cancel booking"
													: "delete booking"
											}
										>
											<DeleteIcon className="delIconColorOverride" />
										</IconButton>
									)}
								<CardContent>
									<Typography
										variant="h6"
										sx={{ color: theme.palette.background.default }}
									>
										<strong>
											{booking.type} - {booking.firstName} {booking.lastName}
										</strong>
									</Typography>
									<Typography sx={{ color: theme.palette.background.default }}>
										<strong>Hotel:</strong> {booking.hotel} -{" "}
										<strong>Suite:</strong> {booking.suite}
									</Typography>
									<Typography sx={{ color: theme.palette.background.default }}>
										<strong>Start:</strong> {formatDate(booking.start)}
									</Typography>
									<Typography>
										<strong>End:</strong> {formatDate(booking.end)}
									</Typography>
									<Typography>
										<strong>Status:</strong> {booking.status}
									</Typography>
									<Typography>
										<strong>Notes:</strong> {booking.notes}
									</Typography>
									<Typography>
										<strong>Actual End:</strong>{" "}
										{booking.actualEnd === "TBA"
											? "TBA"
											: formatDate(booking.actualEnd)}
									</Typography>
									<Typography>
										<strong>Invoice:</strong> {booking.invoice}
									</Typography>
								</CardContent>
							</Card>
						))}
					</Grid>
				</Grid>
				<Dialog
					open={openDialog}
					onClose={handleCloseDialog}
					aria-labelledby="alert-dialog-title"
					aria-describedby="alert-dialog-description"
				>
					<DialogTitle id="alert-dialog-title">
						{isCancelAction ? "Confirm Cancellation" : "Confirm Deletion"}
					</DialogTitle>
					<DialogContent>
						<DialogContentText id="alert-dialog-description">
							{isCancelAction
								? "If you're cancelling this booking within 48 hours of the booking you will incur a cancellation fee. Are you sure you want to cancel this booking?"
								: "Are you sure you want to delete this booking?"}
						</DialogContentText>
					</DialogContent>
					<DialogActions>
						<Button onClick={handleCloseDialog} sx={{ color: "#1a1a1a" }}>
							Nevermind
						</Button>
						<Button
							onClick={isCancelAction ? handleCancel : handleDelete}
							sx={{ color: "#1a1a1a" }}
							autoFocus
						>
							Yes I'm Sure
						</Button>
					</DialogActions>
				</Dialog>
			</Container>
		</ThemeProvider>
	);
}

export default Bookings;
