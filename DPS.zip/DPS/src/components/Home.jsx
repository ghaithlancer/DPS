import React, { useState } from "react";
import {
	Grid,
	Button,
	TextField,
	Container,
	Typography,
	ThemeProvider,
} from "@mui/material";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";
import Menu from "./Menu";
import theme from "../theme";
import { createBooking } from "../api/apiService";
import { useUserState } from "../context/UserContext";

function Home() {
	const { user } = useUserState();
	const [currentService, setCurrentService] = useState("Lift Operator");
	const [formData, setFormData] = useState({
		start: null,
		duration: "3.5",
		suite: "",
		notes: "",
	});

	const serviceRates = {
		"Lift Operator": 35,
		Cleaning: 50,
		Staff: 40,
	};

	const calculatePrice = () => {
		const rate = serviceRates[currentService];
		let hours = parseFloat(formData.duration);
		let extraHours = hours > 6 ? hours - 6 : 0;
		let regularHours = hours - extraHours;
		let overtimeRate = rate * 1.5;
		let basePrice = regularHours * rate + extraHours * overtimeRate;
		let priorityBookingFee = 0;

		if (formData.start) {
			const bookingTime = formData.start.toDate();
			const now = new Date();
			const diff = bookingTime.getTime() - now.getTime();
			if (diff <= 48 * 60 * 60 * 1000) {
				priorityBookingFee = 50;
			}
		}

		const subtotal = basePrice + priorityBookingFee;
		const tax = subtotal * 0.13;
		const total = subtotal + tax;

		return { subtotal, total };
	};

	const handleChange = (name, value) => {
		setFormData((prev) => ({
			...prev,
			[name]: value,
		}));
	};

	const handleSubmit = (e) => {
		e.preventDefault();
		if (!user?.verified) {
			alert("You must be verified to make a booking.");
			return;
		}
		const { total } = calculatePrice();
		if (!formData.start) {
			alert("Please select a date and time.");
			return;
		}
		const formattedStart = formData.start.format("YYYY-MM-DDTHH:mm");
		const formattedTotal = total.toFixed(2);

		createBooking(
			{
				start: formattedStart,
				duration: parseFloat(formData.duration) * 60,
				suite: formData.suite,
				notes: formData.notes,
				price: parseFloat(formattedTotal),
			},
			currentService.replace(" ", "").toLowerCase()
		)
			.then(() => {
				alert("Booking created successfully!");
				setFormData({
					start: null,
					duration: "3.5",
					suite: "",
					notes: "",
				});
			})
			.catch((error) => alert("Failed to create booking: " + error.message));
	};

	return (
		<ThemeProvider theme={theme}>
			<LocalizationProvider dateAdapter={AdapterDayjs}>
				<Container
					maxWidth="md"
					sx={{
						height: "calc(100vh - 64px)", // Adjust 64px based on your actual header/footer total height
						overflowY: "auto",
						WebkitOverflowScrolling: "touch", // for iOS momentum scrolling
						"::-webkit-scrollbar": {
							display: "none",
						},
						msOverflowStyle: "none", // for Internet Explorer and Edge
						scrollbarWidth: "none", // for Firefox
					}}
				>
					<Menu />
					<Grid container spacing={3} sx={{ padding: "20px" }}>
						<Grid
							item
							xs={12}
							sx={{ display: "flex", justifyContent: "center" }}
						>
							{["Lift Operator", "Cleaning", "Staff"].map((service) => (
								<Button
									key={service}
									variant={
										currentService === service ? "contained" : "outlined"
									}
									onClick={() => setCurrentService(service)}
									sx={{
										margin: 0.5,
										backgroundColor:
											currentService === service
												? theme.palette.primary.main
												: "",
										color: currentService === service ? "#1a1a1a" : "#ffffff",
									}}
								>
									<strong>{service}</strong>
								</Button>
							))}
						</Grid>
						<Grid item xs={12}>
							<form onSubmit={handleSubmit}>
								<Grid container spacing={2}>
									<Grid
										item
										xs={16}
										sx={{ display: "flex", justifyContent: "center" }}
									>
										<DateTimePicker
											label="Date & Time"
											value={formData.start}
											onChange={(newValue) => handleChange("start", newValue)}
											inputLabelProps={{
												style: { color: "#fff" }, // Ensures the icon color is white
											}}
										/>
									</Grid>
									<Grid item xs={6}>
										<TextField
											label="Duration (hrs)"
											type="number"
											name="duration"
											inputProps={{
												min: "3.5",
												step: "0.5",
												max: "12",
												style: { color: "#fff" },
											}}
											value={formData.duration}
											onChange={(e) => handleChange("duration", e.target.value)}
											required
											fullWidth
											InputLabelProps={{
												style: { color: "#fff" },
											}}
											InputProps={{
												style: { color: "#fff" },
											}}
										/>
									</Grid>
									<Grid item xs={6}>
										<TextField
											label="Suite #"
											type="number"
											name="suite"
											required
											disabled={currentService === "Staff"}
											value={formData.suite}
											onChange={(e) => handleChange("suite", e.target.value)}
											fullWidth
											InputLabelProps={{
												style: { color: "#fff" }, // Ensures the label text is white
											}}
											InputProps={{
												style: { color: "#fff" }, // Ensures the input text is white
												inputProps: {
													style: { color: "#fff" }, // Additional deep nesting for the actual input
												},
											}}
										/>
									</Grid>
									<Grid item xs={12}>
										<TextField
											label="Notes:"
											name="notes"
											multiline
											rows={4}
											value={formData.notes}
											onChange={(e) => handleChange("notes", e.target.value)}
											fullWidth
											InputLabelProps={{
												style: { color: "#fff" },
											}}
											InputProps={{
												style: { color: "#fff" },
											}}
										/>
									</Grid>
									<Grid item xs={12}>
										<Typography sx={{ color: "gold" }}>
											Subtotal: ${calculatePrice().subtotal.toFixed(2)}
										</Typography>
										<Typography sx={{ color: "gold" }}>
											Total (13% GST Tax incl.): $
											{calculatePrice().total.toFixed(2)}
										</Typography>
									</Grid>
									<Grid item xs={12}>
										<Button
											type="submit"
											variant="contained"
											color="primary"
											fullWidth
											sx={{ color: "#1a1a1a" }}
										>
											<strong>Submit Request</strong>
										</Button>
									</Grid>
								</Grid>
							</form>
						</Grid>
					</Grid>
				</Container>
			</LocalizationProvider>
		</ThemeProvider>
	);
}

export default Home;
