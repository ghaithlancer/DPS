import React, { useState } from "react";
import {
	TextField,
	Button,
	Container,
	Typography,
	Paper,
	Box,
} from "@mui/material";
import { Link, useNavigate } from "react-router-dom";
import { login } from "../api/apiService";
import { useUserDispatch } from "../context/UserContext";
import logo from "../assets/dps_logo.jpg"; // Adjust the path as necessary

function Login() {
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const navigate = useNavigate();
	const dispatch = useUserDispatch();

	const handleLogin = async (e) => {
		e.preventDefault();
		const credentials = { email, password };
		try {
			const { user, token } = await login(credentials);
			dispatch({ type: "SET_USER", payload: user }); // Ensure 'user' is defined correctly
			navigate("/");
		} catch (error) {
			console.error("Error during login:", error);
			alert(
				"Login failed. " + (error.response?.data?.error || "Unknown error")
			);
		}
	};

	return (
		<Container component="main" maxWidth="xs">
			<Paper elevation={6} sx={{ mt: 8, padding: 3 }}>
				<img
					src={logo}
					alt="Logo"
					style={{
						maxWidth: "100%", // Ensures the image does not stretch beyond the container width
						height: "auto", // Maintains the aspect ratio
						display: "block", // Removes extra space below the image
						margin: "0 auto 20px", // Centers the image horizontally and adds spacing below
					}}
				/>
				<Typography component="h1" variant="h5" sx={{ mb: 2 }}>
					Login
				</Typography>
				<form onSubmit={handleLogin}>
					<TextField
						variant="outlined"
						margin="normal"
						fullWidth
						label="Email Address"
						name="email"
						autoComplete="email"
						autoFocus
						value={email}
						onChange={(e) => setEmail(e.target.value)}
						InputLabelProps={{
							style: { color: "#1a1a1a" },
						}}
						InputProps={{
							style: { color: "#1a1a1a" }, // Ensures the input text is white
							inputProps: {
								style: { color: "#1a1a1a" }, // Additional deep nesting for the actual input
							},
						}}
					/>
					<TextField
						variant="outlined"
						margin="normal"
						fullWidth
						name="password"
						label="Password"
						type="password"
						autoComplete="current-password"
						value={password}
						onChange={(e) => setPassword(e.target.value)}
						InputLabelProps={{
							style: { color: "#1a1a1a" },
						}}
						InputProps={{
							style: { color: "#1a1a1a" }, // Ensures the input text is white
							inputProps: {
								style: { color: "#1a1a1a" }, // Additional deep nesting for the actual input
							},
						}}
					/>
					<Button
						type="submit"
						fullWidth
						variant="contained"
						sx={{ mt: 3, mb: 2, color: "#1a1a1a" }}
					>
						<strong>Login</strong>
					</Button>
					<Box textAlign="center">
						<Link to="/signup" style={{ textDecoration: "none" }}>
							Don't have an account? Sign Up
						</Link>
					</Box>
				</form>
			</Paper>
		</Container>
	);
}

export default Login;
