import React from "react";
import {
	Drawer,
	List,
	ListItem,
	ListItemIcon,
	ListItemText,
	Typography,
	Divider,
	IconButton,
	Box,
} from "@mui/material";
import HomeIcon from "@mui/icons-material/Home";
import BookIcon from "@mui/icons-material/Book";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import MenuIcon from "@mui/icons-material/Menu";
import { Link, useNavigate } from "react-router-dom";
import { useUserState, useUserDispatch } from "../context/UserContext";
import "./style.css";

function Menu() {
	const { user } = useUserState();
	const dispatch = useUserDispatch();
	const navigate = useNavigate();
	const [isOpen, setIsOpen] = React.useState(false);

	const toggleDrawer = (open) => (event) => {
		if (
			event.type === "keydown" &&
			(event.key === "Tab" || event.key === "Shift")
		) {
			return;
		}
		setIsOpen(open);
	};

	const handleLogout = () => {
		dispatch({ type: "LOGOUT" });
		navigate("/login");
	};

	return (
		<div>
			<IconButton onClick={toggleDrawer(true)} sx={{ color: "#ffffff" }}>
				<MenuIcon />
			</IconButton>
			<Drawer anchor="left" open={isOpen} onClose={toggleDrawer(false)}>
				<Box sx={{ width: 250, bgcolor: "#ffd700", height: "100%" }}>
					<Box sx={{ padding: "16px" }}>
						<Typography variant="h6" noWrap sx={{ color: "#1a1a1a" }}>
							{user.firstName} {user.lastName}
						</Typography>
						<Typography variant="subtitle1" noWrap sx={{ color: "#1a1a1a" }}>
							{user.hotel}
						</Typography>
						<Divider sx={{ bgcolor: "#1a1a1a", my: 2 }} />
						<List>
							<ListItem
								button
								component={Link}
								to="/"
								onClick={toggleDrawer(false)}
							>
								<ListItemIcon>
									<HomeIcon className="iconColorOverride" />
								</ListItemIcon>
								<ListItemText primary="Home" />
							</ListItem>
							<ListItem
								button
								component={Link}
								to="/bookings"
								onClick={toggleDrawer(false)}
							>
								<ListItemIcon>
									<BookIcon className="iconColorOverride" />
								</ListItemIcon>
								<ListItemText primary="Bookings" />
							</ListItem>
							<ListItem button onClick={handleLogout}>
								<ListItemIcon>
									<ExitToAppIcon className="iconColorOverride" />
								</ListItemIcon>
								<ListItemText primary="Logout" />
							</ListItem>
						</List>
					</Box>
				</Box>
			</Drawer>
		</div>
	);
}

export default Menu;
