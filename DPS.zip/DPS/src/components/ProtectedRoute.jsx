import React from "react";
import { Navigate } from "react-router-dom";
import { useUserState } from "../context/UserContext";

function ProtectedRoute({ children }) {
	const { isAuthenticated } = useUserState(); // Access isAuthenticated as a property, not a function

	if (!isAuthenticated) {
		// Check if isAuthenticated is false directly
		return <Navigate to="/login" replace />;
	}

	return children; // Render children if the user is authenticated
}

export default ProtectedRoute;
