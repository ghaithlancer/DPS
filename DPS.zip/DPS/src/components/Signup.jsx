import React, { useState } from "react";
import {
	TextField,
	Button,
	Container,
	Typography,
	Paper,
	Box,
	MenuItem,
	FormControl,
	InputLabel,
	Select,
} from "@mui/material";
import { Link, useNavigate } from "react-router-dom";
import { signup } from "../api/apiService"; // Assuming this function is implemented
import { useUserDispatch } from "../context/UserContext";

function Signup() {
	const [formData, setFormData] = useState({
		firstName: "",
		lastName: "",
		email: "",
		password: "",
		confirmPassword: "",
		hotel: "",
		otherHotel: "", // For custom hotel name
	});
	const [showOtherField, setShowOtherField] = useState(false);
	const navigate = useNavigate();
	const dispatch = useUserDispatch();

	const handleSignup = async (e) => {
		e.preventDefault();
		if (formData.password !== formData.confirmPassword) {
			alert("Passwords do not match!");
			return;
		}
		const data = {
			firstName: formData.firstName,
			lastName: formData.lastName,
			email: formData.email,
			password: formData.password,
			hotel: formData.hotel === "Other" ? formData.otherHotel : formData.hotel,
		};
		try {
			const response = await signup(data);
			dispatch({ type: "SET_USER", payload: response.data.user });
			navigate("/"); // Navigate to home on successful signup
		} catch (error) {
			alert(
				"Signup failed: " + (error.response?.data?.message || "Unknown error")
			);
		}
	};

	const handleChange = (event) => {
		const { name, value } = event.target;
		setFormData({ ...formData, [name]: value });

		if (name === "hotel" && value === "Other") {
			setShowOtherField(true);
		} else {
			setShowOtherField(false);
		}
	};

	return (
		<Container component="main" maxWidth="xs">
			<Paper elevation={6} sx={{ mt: 8, padding: 3 }}>
				<Typography component="h1" variant="h5" sx={{ mb: 2 }}>
					Sign Up
				</Typography>
				<form onSubmit={handleSignup}>
					<TextField
						variant="outlined"
						margin="normal"
						required
						fullWidth
						label="First Name"
						name="firstName"
						autoComplete="given-name"
						autoFocus
						value={formData.firstName}
						onChange={handleChange}
						InputLabelProps={{
							style: { color: "#1a1a1a" },
						}}
						InputProps={{
							style: { color: "#1a1a1a" },
							inputProps: {
								style: { color: "#1a1a1a" },
							},
						}}
					/>
					<TextField
						variant="outlined"
						margin="normal"
						required
						fullWidth
						label="Last Name"
						name="lastName"
						autoComplete="family-name"
						value={formData.lastName}
						onChange={handleChange}
						InputLabelProps={{
							style: { color: "#1a1a1a" },
						}}
						InputProps={{
							style: { color: "#1a1a1a" },
							inputProps: {
								style: { color: "#1a1a1a" },
							},
						}}
					/>
					<TextField
						variant="outlined"
						margin="normal"
						required
						fullWidth
						label="Email Address"
						name="email"
						autoComplete="email"
						value={formData.email}
						onChange={handleChange}
						InputLabelProps={{
							style: { color: "#1a1a1a" },
						}}
						InputProps={{
							style: { color: "#1a1a1a" },
							inputProps: {
								style: { color: "#1a1a1a" },
							},
						}}
					/>
					<FormControl fullWidth variant="outlined" margin="normal">
						<InputLabel id="hotel-label" style={{ color: "#1a1a1a" }}>
							Hotel
						</InputLabel>
						<Select
							labelId="hotel-label"
							id="hotel"
							name="hotel"
							value={formData.hotel}
							onChange={handleChange}
							label="Hotel"
							InputLabelProps={{
								style: { color: "#1a1a1a" },
							}}
							InputProps={{
								style: { color: "#1a1a1a" },
								inputProps: {
									style: { color: "#1a1a1a" },
								},
							}}
						>
							<MenuItem value="Ritz Carlton">Ritz Carlton</MenuItem>
							<MenuItem value="Shangri-La">Shangri-La</MenuItem>
							<MenuItem value="NOBU" disabled>
								NOBU
							</MenuItem>
							<MenuItem value="Other">Other</MenuItem>
						</Select>
					</FormControl>
					{showOtherField && (
						<TextField
							variant="outlined"
							margin="normal"
							required
							fullWidth
							name="hotel"
							label="Hotel Name"
							type="text"
							value={formData.hotel}
							onChange={(e) =>
								handleChange({
									target: { name: "hotel", value: e.target.value },
								})
							}
							InputLabelProps={{
								style: { color: "#1a1a1a" },
							}}
							InputProps={{
								style: { color: "#1a1a1a" },
								inputProps: {
									style: { color: "#1a1a1a" },
								},
							}}
						/>
					)}
					<TextField
						variant="outlined"
						margin="normal"
						required
						fullWidth
						name="password"
						label="Password"
						type="password"
						autoComplete="new-password"
						value={formData.password}
						onChange={handleChange}
						InputLabelProps={{
							style: { color: "#1a1a1a" },
						}}
						InputProps={{
							style: { color: "#1a1a1a" },
							inputProps: {
								style: { color: "#1a1a1a" },
							},
						}}
					/>
					<TextField
						variant="outlined"
						margin="normal"
						required
						fullWidth
						name="confirmPassword"
						label="Confirm Password"
						type="password"
						value={formData.confirmPassword}
						onChange={handleChange}
						InputLabelProps={{
							style: { color: "#1a1a1a" },
						}}
						InputProps={{
							style: { color: "#1a1a1a" },
							inputProps: {
								style: { color: "#1a1a1a" },
							},
						}}
					/>
					<Button
						type="submit"
						fullWidth
						variant="contained"
						color="primary"
						sx={{ mt: 3, mb: 2 }}
					>
						<strong>Sign Up</strong>
					</Button>
					<Box textAlign="center">
						<Link to="/login" style={{ textDecoration: "none" }}>
							Already have an account? Login
						</Link>
					</Box>
				</form>
			</Paper>
		</Container>
	);
}

export default Signup;
