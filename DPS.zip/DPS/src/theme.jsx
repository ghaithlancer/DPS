import { createTheme } from "@mui/material/styles";

const theme = createTheme({
	palette: {
		primary: {
			main: "#ffd700", // Gold color
		},
		background: {
			default: "#1a1a1a", // Off black background
		},
		text: {
			primary: "#1a1a1a", // White text
		},
	},
	components: {
		MuiTextField: {
			styleOverrides: {
				root: {
					"& label.Mui-focused": {
						color: "#ffffff", // Dark label when focused
					},
					"& .MuiInput-underline:after": {
						borderBottomColor: "#ffffff", // Dark underline when focused
					},
					"& .MuiOutlinedInput-root": {
						"& fieldset": {
							borderColor: "#ffffff", // Dark border
						},
						"&:hover fieldset": {
							borderColor: "#ffffff", // Dark border on hover
						},
						"&.Mui-focused fieldset": {
							borderColor: "#ffffff", // Dark border when focused
						},
						"& input": {
							color: "#fff", // Set text color to dark for all input fields
						},
					},
					' & input[type="datetime-local"]::-webkit-calendar-picker-indicator':
						{
							filter: "invert(1)", // Inverts the color to white if the default is black
						},
				},
			},
		},
		MuiInputLabel: {
			styleOverrides: {
				root: {
					color: "#ffffff", // Ensuring label is always white
					"&.Mui-focused": {
						color: "#ffffff", // Ensuring label remains white when focused
					},
				},
			},
		},
		MuiButton: {
			styleOverrides: {
				root: {
					color: "#1a1a1a", // White text for buttons
				},
			},
		},
		MuiSvgIcon: {
			// Targeting all SVG icons globally, adjust as needed
			styleOverrides: {
				root: {
					color: "#ffffff", // Ensures all icons are white unless otherwise specified
				},
			},
		},
	},
});

export default theme;
