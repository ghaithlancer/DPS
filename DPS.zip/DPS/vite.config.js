import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
	plugins: [
		react(),
		VitePWA({
			registerType: "autoUpdate", // This controls how the service worker updates
			injectRegister: "auto", // Automatically handles the registration of the service worker
			// includeAssets: ["favicon.svg", "robots.txt"], // Include additional assets to be precached
			manifest: {
				name: "Don's Premium Services",
				short_name: "DPS",
				description: "App to book various services",
				theme_color: "#ffffff",
				icons: [
					// Defines icons for various devices and contexts
					{
						src: "logo/dps_logo.jpg",
						sizes: "192x192",
						type: "image/png",
						purpose: "any maskable",
					},
					{
						src: "logo/dps_logo.jpg",
						sizes: "512x512",
						type: "image/png",
						purpose: "any maskable",
					},
				],
				start_url: ".", // The start URL of your PWA
				display: "standalone", // Display mode
				background_color: "#ffffff", // Background color
			},
			workbox: {
				globPatterns: ["**/*.{js,css,html,ico,png,svg}"], // Patterns to determine which files to precache
			},
		}),
	],
	build: {
		outDir: "dist", // Optional, specify output directory
	},
});
